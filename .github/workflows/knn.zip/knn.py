import cv2
import numpy as np
import os

# Load face images from the dataset
def load_images_and_labels(dataset_path, image_size=(100, 100)):
    face_images = []
    labels = []
    
    for file in os.listdir(dataset_path):
        if file.endswith('.jpg'):
            label = (file.split('_')[1]) #라벨 위치, 초성으로 찍히게 수정 필요
            img = cv2.imread(os.path.join(dataset_path, file), cv2.IMREAD_GRAYSCALE)
            img_resized = cv2.resize(img, image_size)
            face_images.append(img_resized.flatten())
            labels.append(label)
    
    return np.array(face_images), np.array(labels)

dataset_path = r'C:\Users\LeeDongwon\Desktop\workspace\opencv\img' # 이미지 주소
face_images, labels = load_images_and_labels(dataset_path)

def compute_pca(data, n_components):
    mean = np.mean(data, axis=0)  # 평균 얼굴 계산
    centered_data = data - mean  # 데이터 중심화
    covariance_matrix = np.cov(centered_data, rowvar=False)  # 공분산 행렬 계산
    eigenvalues, eigenvectors = np.linalg.eigh(covariance_matrix)  # 고유값과 고유벡터 계산
    
    sorted_indices = np.argsort(eigenvalues)[::-1]  # 고유값 내림차순 정렬
    sorted_eigenvectors = eigenvectors[:, sorted_indices]  # 고유벡터 정렬
    selected_eigenvectors = sorted_eigenvectors[:, :n_components]  # 필요한 수의 고유벡터 선택
    
    pca_data = np.dot(centered_data, selected_eigenvectors)  # PCA 변환 데이터
    return selected_eigenvectors, mean, pca_data

eigenvectors, mean_face, pca_faces = compute_pca(face_images, n_components=50)  # PCA 적용

def euclidean_distance(a, b):
    return np.sqrt(np.sum((a - b) ** 2))  # 유클리드 거리 계산

# knn 최근접 이웃 학습모델 별로 분류성능이 별로 않좋은거 같음
def knn_classify(train_data, train_labels, test_data, k=3):
    distances = []
    for i in range(len(train_data)):
        dist = euclidean_distance(train_data[i], test_data)
        distances.append((dist, train_labels[i]))  # 거리와 레이블 저장
    distances.sort(key=lambda x: x[0])  # 거리 순으로 정렬
    neighbors = [distances[i][1] for i in range(k)]  # 가장 가까운 k개의 이웃 선택
    prediction = max(set(neighbors), key=neighbors.count)  # 다수결로 예측
    return prediction

def recognize_faces(eigenvectors, mean_face, train_data, train_labels):
    cam = cv2.VideoCapture(0)  # 웹캠 시작
    face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")  # 얼굴 검출기
    
    while True:
        ret, img = cam.read()  # 이미지 읽기
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # 회색조로 변환
        faces = face_detector.detectMultiScale(gray, 1.3, 5)  # 얼굴 검출
        
        for (x, y, w, h) in faces:
            face = gray[y:y+h, x:x+w].flatten()  # 얼굴 부분 추출 및 평탄화
            face_resized = cv2.resize(face.reshape(h, w), (100, 100)).flatten()  # 얼굴 크기 조정 및 평탄화
            face_centered = face_resized - mean_face  # 얼굴 중심화
            face_pca = np.dot(face_centered, eigenvectors)  # PCA 변환
            
            prediction = knn_classify(train_data, train_labels, face_pca)  # 얼굴 예측
            label = f"ID: {prediction}"  # 예측 결과 라벨
            cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)  # 얼굴 부분에 사각형 그리기
            cv2.putText(img, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)  # 얼굴 위에 텍스트 표시
        
        cv2.imshow('Face Recognition', img)  # 결과 이미지 보여주기
        
        if cv2.waitKey(10) & 0xFF == 27:  # ESC 키를 누르면 종료
            break

    cam.release()  # 웹캠 해제
    cv2.destroyAllWindows()  # 모든 창 닫기

# Run face recognition
recognize_faces(eigenvectors, mean_face, pca_faces, labels)  # 얼굴 인식 실행
